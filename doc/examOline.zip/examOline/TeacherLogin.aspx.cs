﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["teacherID"] == "")
            Response.Redirect("Login.aspx");
        else if (!IsPostBack)
        {
            string teacherid = Session["teacherID"].ToString();
            SqlConnection conn = BaseClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_teacher where teacherID='" + Session["teacherID"].ToString() + "'", conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            lbl_teacherName.Text = sdr["TeacherName"].ToString();
            conn.Close();
            Session["TeacherName"] = lbl_teacherName.Text;
        }
    }
}
