﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Data.SqlClient;

public partial class Teacher_AddExamination : System.Web.UI.Page
{
    string teacherid;
    //SqlConnection conn = new SqlConnection("server=localhost;database=xTest;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
                teacherid = Session["teacherID"].ToString();
                SqlConnection conn = BaseClass.DBCon();
                conn.Open();
                SqlCommand cmd = new SqlCommand("select * from tb_teacher where teacherID='" + Session["teacherID"].ToString() + "'", conn);
                SqlDataReader sdr = cmd.ExecuteReader();
                sdr.Read();
                //lblTeacher.Text = sdr["TeacherName"].ToString();
                Label1.Text = sdr["courseID"].ToString();
                conn.Close();
                Session["courseID"] = Label1.Text;
                SqlConnection conn1 = BaseClass.DBCon();
                conn1.Open();
                SqlCommand cmd1 = new SqlCommand("select * from tb_course where courseID='" + Session["courseID"].ToString() + "'", conn1);
                SqlDataReader sdr1 = cmd1.ExecuteReader();
                sdr1.Read();
                lblCourseName.Text = sdr1["courseName"].ToString();
                conn1.Close();
                Session["courseName"] = lblCourseName.Text;
                
        }
        lblCourseName.Text = Session["courseName"].ToString();

    }
    //添加单选题
    protected void btnConfirm_Click(object sender, EventArgs e)
    {
        string answer = "";
        for (int i = 0; i < rblAnswer.Items.Count; i++)
        {
                answer = rblAnswer.Items[i].Value;

        }
        string str = "insert into [xTest].[dbo].tb_schoose(questionText,chooseA,chooseB,chooseC,chooseD,answer,courseID) values('" + txtContent.Text + "','" + txtAnsA.Text + "','" + txtAnsB.Text + "','" + txtAnsC.Text + "','" + txtAnsD.Text + "','" + answer + "','" + Label1.Text + "')";

        Response.Write("<script lanuage=javascript>alert('出题成功！')</script>");
 

        //调用公共类的方法，向数据库插入记录
        BaseClass.OperateData(str);
        btnCancel_Click(sender, e);
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtContent.Text = "";
        txtAnsD.Text = "";
        txtAnsC.Text = "";
        txtAnsB.Text = "";
        txtAnsA.Text = "";
        txtContent.Focus();
    } 
}
