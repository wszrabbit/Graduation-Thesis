﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Teacher_ManagerQuestionSC : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["teacherID"] == null)
        //{
        //    Response.Redirect("../Login.aspx");
        //}
        if (!IsPostBack)
        {
            gvExaminationInfo_Bind();
        }
    }

    public void gvExaminationInfo_Bind()
    {
        //string teacherid = Session["teacherID"].ToString();
        SqlConnection conn = BaseClass.DBCon();
        conn.Open();
        SqlCommand cmd = new SqlCommand("select courseID from tb_teacher where teacherID='" + Session["teacherID"].ToString() + "'", conn);
        SqlDataReader sdr = cmd.ExecuteReader();
        sdr.Read();
       string cid=sdr["courseID"].ToString();
        conn.Close();
        //Session["courseID"] = Label1.Text;
        string strsql = "select * from tb_schoose where courseID='" + cid + "'";
        BaseClass.BindDG(gvExaminationInfo, "questionID", strsql, "SingleChooseInfo");
        conn.Open();
        SqlCommand cmd1 = new SqlCommand("select * from tb_schoose", conn);
        SqlDataReader sdr1 = cmd1.ExecuteReader();
        ////this.ddlEkm.DataSource = sdr1;
        ////this.ddlEkm.DataTextField = "courseID";
        ////this.ddlEkm.DataValueField = "questionID";
        ////this.ddlEkm.DataBind();
        conn.Close();
    }
    protected void gvExaminationInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvExaminationInfo.PageIndex = e.NewPageIndex;
        gvExaminationInfo_Bind();
    }
    //protected void btnSerch_Click(object sender, EventArgs e)
    //{
    //    string s = ddlEkm.SelectedItem.Text;
    //    int i;
    //    if (s == "是")
    //    {
    //        i = 1;
    //        string strsql = "select * from tb_schoose where courseID='" + Session["courseID"].ToString()+"'";
    //        BaseClass.BindDG(gvExaminationInfo, "questionID", strsql, "SingleChooseInfo");
    //        SqlConnection conn1 = BaseClass.DBCon();
    //        conn1.Open();
    //        SqlCommand cmd1 = new SqlCommand("select * from tb_schoose", conn1);
    //        SqlDataReader sdr1 = cmd1.ExecuteReader();
    //        conn1.Close();
    //    }
    //    else
    //    {
    //        string strsql1 = "select * from tb_schoose where courseID and share='0''" + Session["courseID"].ToString() + "'";
    //        BaseClass.BindDG(gvExaminationInfo, "questionID", strsql1, "SingleChooseInfo");
    //        SqlConnection conn2 = BaseClass.DBCon();
    //        conn2.Open();
    //        SqlCommand cmd2 = new SqlCommand("select * from tb_schoose", conn2);
    //        SqlDataReader sdr2 = cmd2.ExecuteReader();
    //        conn2.Close();
    //    }
    //    //lbltype.Text = ddlEkm.SelectedItem.Text.Trim();
    //    //string strsql = "select * from tb_schoose where courseID ='" + ddlEkm.SelectedItem.Text.Trim() + "'";
    //    //BaseClass.BindDG(gvExaminationInfo, "questionID", strsql, "SingleChooseInfo");
    //    //SqlConnection conn = BaseClass.DBCon();
    //    //conn.Open();
    //    //SqlCommand cmd = new SqlCommand("select * from tb_schoose", conn);
    //    //SqlDataReader sdr = cmd.ExecuteReader();
    //    //this.ddlEkm.DataSource = sdr;
    //    //this.ddlEkm.DataTextField = "courseID";
    //    //this.ddlEkm.DataValueField = "questionID";
    //    //this.ddlEkm.DataBind(); 
    //}
    protected void ddlEkm_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void gvExaminationInfo_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void btnSerch_Click(object sender, EventArgs e)
    {
        Response.Redirect("AddQuestionSC.aspx");
    }
}
