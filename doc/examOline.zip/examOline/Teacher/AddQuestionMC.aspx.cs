﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class MChoose_MChooseInsert : System.Web.UI.Page
{
    string teacherid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //teacherid = Session["teacherID"].ToString();
            SqlConnection conn = BaseClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_teacher where teacherID='" + Session["teacherID"].ToString() + "'", conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            Label1.Text = sdr["courseID"].ToString();
            conn.Close();
            //Session["courseID"] = Label1.Text;
            //Label1.Text = Session["courseID"].ToString();
            SqlConnection conn1 = BaseClass.DBCon();
            conn1.Open();
            SqlCommand cmd1 = new SqlCommand("select * from tb_course where courseID='" + Label1.Text + "'", conn1);
            SqlDataReader sdr1 = cmd1.ExecuteReader();
            sdr1.Read();
            lblCourseName.Text = sdr1["courseName"].ToString();
            conn1.Close();
            //Session["courseName"] = lblCourseName.Text;
        }
        //lblCourseName.Text = Session["courseName"].ToString();
        
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {
        string str1="";
        for (int i = 0; i < CkbAnswer.Items.Count; i++)
        {
            if (CkbAnswer.Items[i].Selected == true)
            { 
                str1 += CkbAnswer.Items[i].Value;
            }
        }
        string str = "INSERT INTO [xTest].[dbo].[tb_mchoose]([questionText], [chooseA], [chooseB], [chooseC], [chooseD], [chooseE], [chooseF], [chooseG], [chooseH], [chooseI], [answer],[courseID])VALUES('" + txtContent.Text.Trim() + "','" + txtAnsA.Text.Trim() + "','" + txtAnsB.Text.Trim() + "','" + txtAnsC.Text.Trim() + "','" + txtAnsD.Text.Trim() + "','" + txtAnsE.Text.Trim() + "','" + txtAnsF.Text.Trim() + "','" + txtAnsG.Text.Trim() + "','" + txtAnsH.Text.Trim() + "','" + txtAnsI.Text.Trim() + "','" + str1.Trim() + "','" + Label1.Text.Trim() + "')";
       
        Response.Write("<script lanuage=javascript>alert('出题成功！')</script>");
      
       
        //for (int i=0; i < CkbAnswer.Items.Count; i++)
        //{ CkbAnswer.Items[i].Selected = false; }
        BaseClass.OperateData(str);
        btnClose_Click(sender, e);
    }
    protected void btnClose_Click(object sender, EventArgs e)
    {
        //txtNum.Text = "";
        txtContent.Text = "";
        txtAnsA.Text = "";
        txtAnsB.Text = "";
        txtAnsC.Text = "";
        txtAnsD.Text = "";
        txtAnsE.Text = "";
        txtAnsF.Text = "";
        //txtNum.Focus();
        txtAnsH.Text = "";
        txtAnsI.Text = "";
    }
}
