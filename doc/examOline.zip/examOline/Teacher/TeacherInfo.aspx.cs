﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Teacher_TeacherInfo : System.Web.UI.Page
{
    string cid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection conn = BaseClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_teacher where teacherID=" + Session["teacherID"].ToString(), conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                txtname.Text = sdr["teacherName"].ToString();
                txtID.Text = sdr["teacherID"].ToString();
                txtpwd.Text = sdr["teacherPwd"].ToString();
                cid = sdr["courseID"].ToString();
                for (int a = 0; a < rblsex.Items.Count; a++)
                {
                    if (rblsex.Items[a].Text == sdr["Sex"].ToString().Trim())
                        rblsex.Items[a].Selected = true;
                }
            }
            conn.Close();
            conn.Open();
            //string cmdStr = ;
            SqlCommand cmd1 = new SqlCommand("select courseName from tb_course  where courseID="+cid, conn);
            SqlDataReader sdr1 = cmd1.ExecuteReader();
            sdr1.Read();
            txtpwd0.Text = sdr1["courseName"].ToString();
            conn.Close();
        }
    }
    protected void btnok_Click(object sender, EventArgs e)
    {
        Response.Redirect("TeacherLogin.aspx");
    }
}