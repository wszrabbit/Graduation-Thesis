﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Teacher_AssembledExam : System.Web.UI.Page
{
    string id;
    string sdt;
    string edt;
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string ExamID = Request.QueryString["ExamID"];
            txtExamID.Text = Request.QueryString["ExamID"].ToString();
            string str = "select * from tb_class";
            BaseClass.BindDDL(ddlClass, "ClassName", "ClassID", str, "tb_class");
	            conn.Open();
                SqlCommand cmd = new SqlCommand("select * from tb_examInfo where ExamID=" + ExamID, conn);
	            SqlDataReader sdr = cmd.ExecuteReader();
	            while (sdr.Read())
	            {
	                txtStartTime.Text = sdr["StartTime"].ToString();
	                txtEndTime.Text = sdr["EndTime"].ToString();
	                txtSchooseNum.Text = sdr["SChooseNum"].ToString();
	                txtSchoosePoint.Text = sdr["SchoosePoint"].ToString();
	                txtMchooseNum.Text = sdr["MchooseNum"].ToString();
	                txtMchoosePoint.Text = sdr["MchoosePoint"].ToString();
	                txtInputNum.Text = sdr["InputNum"].ToString();
	                txtInputPoint.Text = sdr["InputPoint"].ToString();
	                txtJudgeNum.Text = sdr["JudgeNum"].ToString();
	                txtJudgePoint.Text = sdr["JudgePoint"].ToString();
	                txtApplicationNum.Text = sdr["ApplicationNum"].ToString();
	                txtApplicationPoint.Text = sdr["ApplicationPoint"].ToString();
                    ddlClass.SelectedValue = sdr["ClassID"].ToString();
                    lblStat.Text = "100";
	            }
	            conn.Close();                
            }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
       btnStat_Click(sender, e);
               txtExamID.Text = Request.QueryString["ExamID"].ToString();
               if (sdt == null && edt == null)
               {
                   string strSql = " UPDATE [tb_examInfo] set [SChooseNum] = '" + txtSchooseNum.Text.Trim() + "',[ClassID]='" + ddlClass.SelectedValue.ToString() + "',[SChoosePoint]='" + txtSchoosePoint.Text.Trim() + "',[MChooseNum]='" + txtMchooseNum.Text.Trim() + "',[MChoosePoint]='" + txtMchoosePoint.Text.Trim() + "',[InputNum]='" + txtInputNum.Text.Trim() + "',[InputPoint]='" + txtInputPoint.Text.Trim() + "',[JudgeNum]='" + txtJudgeNum.Text.Trim() + "',[JudgePoint]='" + txtJudgePoint.Text.Trim() + "',[ApplicationNum]='" + txtApplicationNum.Text.Trim() + "',[ApplicationPoint]='" + txtApplicationPoint.Text.Trim() + "' where ExamID='" + txtExamID.Text.Trim() + "'";
                   BaseClass.OperateData(strSql);
               }
               else
               {
                   string strSql = " UPDATE [tb_examInfo] set [SChooseNum] = '" + txtSchooseNum.Text.Trim() + "',[ClassID]='" + ddlClass.SelectedValue.ToString() + "',[SChoosePoint]='" + txtSchoosePoint.Text.Trim() + "',[MChooseNum]='" + txtMchooseNum.Text.Trim() + "',[MChoosePoint]='" + txtMchoosePoint.Text.Trim() + "',[InputNum]='" + txtInputNum.Text.Trim() + "',[InputPoint]='" + txtInputPoint.Text.Trim() + "',[JudgeNum]='" + txtJudgeNum.Text.Trim() + "',[JudgePoint]='" + txtJudgePoint.Text.Trim() + "',[ApplicationNum]='" + txtApplicationNum.Text.Trim() + "',[ApplicationPoint]='" + txtApplicationPoint.Text.Trim() + "',[StartTime]='" + sdt + "',[EndTime]='" + edt + "' where ExamID='" + txtExamID.Text.Trim() + "'";
                   BaseClass.OperateData(strSql);
               }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("WorkCreatExam.aspx");
    }
    protected void btnStat_Click(object sender, EventArgs e)
    {
        DateTime t1;
        DateTime t2;
        sdt = StartDate.Value.ToString() + " " + StartTime.Value.ToString();
        edt = StartDate.Value.ToString() + " " + EndTime.Value.ToString();
        t1 = DateTime.Parse(sdt);
        t2 = DateTime.Parse(edt);
     
        int a = 0, b = 0, c = 0, d = 0, f = 0;
        if (txtSchoosePoint.Text.ToString().Trim() != "" && txtSchooseNum.Text.ToString().Trim() != "")
            a = Int32.Parse(txtSchoosePoint.Text.ToString().Trim()) * Int32.Parse(txtSchooseNum.Text.ToString().Trim());

        if (txtMchoosePoint.Text.ToString().Trim() != "" && txtMchooseNum.Text.ToString().Trim() != "")
            b = Int32.Parse(txtMchoosePoint.Text.ToString().Trim()) * Int32.Parse(txtMchooseNum.Text.ToString().Trim());

        if (txtInputPoint.Text.ToString().Trim() != "" && txtInputNum.Text.ToString().Trim() != "")
            c = Int32.Parse(txtInputPoint.Text.ToString().Trim()) * Int32.Parse(txtInputNum.Text.ToString().Trim());

        if (txtJudgePoint.Text.ToString().Trim() != "" && txtJudgeNum.Text.ToString().Trim() != "")
            d = Int32.Parse(txtJudgePoint.Text.ToString().Trim()) * Int32.Parse(txtJudgeNum.Text.ToString().Trim());

        if (txtApplicationPoint.Text.ToString().Trim() != "" && txtApplicationNum.Text.ToString().Trim() != "")
            f = Int32.Parse(txtApplicationPoint.Text.ToString().Trim()) * Int32.Parse(txtApplicationNum.Text.ToString().Trim());

        lblStat.Text = (a + b + c + d + f).ToString();
           if (int.Parse(lblStat.Text) < 100)
        {
            Response.Write("<script lanuage=javascript>alert('试卷总分不足100，请重新分配分数');</script>");
        }
        else if(int.Parse(lblStat.Text) > 100)
        {
            Response.Write("<script lanuage=javascript>alert('试卷总分超过100，请重新分配分数');</script>");
        }
           else if (int.Parse(lblStat.Text) == 100)
           {
               if (edt != null && sdt != null)
               {
                   if (DateTime.Compare(t1, t2) >= 0)
                       Response.Write("<script>alert('时间设置不正确');</script>");
                   else
                       Response.Write("<script>alert('修改成功');</script>");
               }
           }
    }
}
