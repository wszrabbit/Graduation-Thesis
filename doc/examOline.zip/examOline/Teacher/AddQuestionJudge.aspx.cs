﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Teacher_AddQuestionJudge : System.Web.UI.Page
{
    string teacherid;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        if(Session["teacherID"]!=null){
        {
            //teacherid = Session["teacherID"].ToString();
            SqlConnection conn = BaseClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_teacher where teacherID='" + Session["teacherID"].ToString() + "'", conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            //lblTeacher.Text = sdr["TeacherName"].ToString();
            Label1.Text = sdr["courseID"].ToString();
            conn.Close();

            SqlConnection conn1 = BaseClass.DBCon();
            conn1.Open();
            SqlCommand cmd1 = new SqlCommand("select * from tb_course where courseID='" + Label1.Text + "'", conn1);
            SqlDataReader sdr1 = cmd1.ExecuteReader();
            sdr1.Read();
            lblCourseName.Text = sdr1["courseName"].ToString();
            conn1.Close();
        }
        }
    }
    protected void btnConfirm_Click(object sender, EventArgs e)//单击确定按钮的事件
    {
        string str = "insert into tb_judge(questionText,answer,courseID) values('" + txtContent.Text.Trim() + "','" + rblRightAns.SelectedValue.ToString() + "','" + Label1.Text + "')";

        //调用公共类的方法，向数据库插入记录
        Response.Write("<script lanuage=javascript>alert('出题成功！')</script>");
        BaseClass.OperateData(str);
        btnCancel_Click(sender, e);
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        txtContent.Text = "";
        txtContent.Focus();
    }
}
