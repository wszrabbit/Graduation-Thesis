﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
public partial class Teacher_CreateExam : System.Web.UI.Page
{
    string ExamID;
    //string ExamID = "";//试卷编号
    string Schoose;//单选题数
    string Mchoose;
    string Judge;//判断题数
    string Input;//填空题数
    string application;//应用题数
    string cid;
    int b = 0,c=0,d=0,k=0,f=0;
    public DataTable datatable = null;
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
             ExamID = Request.QueryString["ExamID"];
            string teacherid = Session["teacherID"].ToString();
            conn.Open();
            SqlCommand cmd1 = new SqlCommand("select * from tb_teacher where teacherID='" + Session["teacherID"].ToString() + "'", conn);
            SqlDataReader sdr1 = cmd1.ExecuteReader();
            sdr1.Read();
            cid = sdr1["courseID"].ToString();
            conn.Close();

            SqlCommand cmd = new SqlCommand("select * from tb_ExamInfo where ExamID='" + ExamID + "'", conn);
            conn.Open();
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                Schoose = sdr["SChooseNum"].ToString();
                Mchoose = sdr["MChooseNum"].ToString();
                Judge = sdr["JudgeNum"].ToString();
                Input = sdr["InputNum"].ToString();
                application = sdr["ApplicationNum"].ToString();

                lblSchoose.Text = "共有" + Schoose + "道题";
                lblMchoose.Text = "共有" + Mchoose + "道题";
                lblJudge.Text = "共有" + Judge + "道题";
                lblInput.Text = "共有" + Input + "道题";
                lblApplication.Text = "共有" + application + "道题";
                lblSchoose.Text = "共有" + Schoose + "道题";
            }
            conn.Close();
            //显示试卷中包含的题目类型的按钮
            btnOK.Enabled = true;
            if (Schoose != "0")
            {
                gvSchoose_Bind();
                btnSchoose.Visible = true;
            }
            if (Mchoose != "0")
            {
                gvMchoose_Bind();
                btnMchoose.Visible = true;
            }
            if (Input != "0")
            {
                gvInput_Bind();
                btninput.Visible = true;
            }
            if (application != "0")
            {
                gvApplication_Bind();
                btnApplication.Visible = true;
            }
            if (Judge != "0")
            {
                gvJudge_Bind();
                btnJudge.Visible = true;
            }           
        }
    }
    //显示单选题以及选择情况
    public void gvSchoose_Bind()
    {
        string strsql1 = "select * from tb_schoose where courseID='" + cid + "'";
        BaseClass.BindDG(gvSchoose, "questionID", strsql1, "tb_schoose");
        string sql = "select * from tb_workexam where SubjectType='单选' and ExamID='" + ExamID + "'";
        conn.Open();
        SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, conn);
        DataSet dataset = new DataSet();
        dataAdapter.Fill(dataset, "tb_workexam");
        datatable = dataset.Tables["tb_workexam"];
        conn.Close();
        for (int i = 0; i < gvSchoose.Rows.Count; i++)
        {
            for (int j = 0; j < datatable.Rows.Count; j++)
            {
                 //string eid = gvSchoose.Rows[i]["questionID"].ToString().Trim();
                if (gvSchoose.DataKeys[i].Value.ToString() == datatable.Rows[j]["questionID"].ToString())
                {
                    ((CheckBox)gvSchoose.Rows[i].FindControl("cbPitch")).Checked = true;
                    b++;
                    lblSchoose1.Text = b.ToString() + "题";
                }
            }
        }
    }
    //显示单选题以及选择情况
    public void gvMchoose_Bind()
    {
        string strsql5 = "select * from tb_mchoose where courseID='" + cid + "'";
        BaseClass.BindDG(gvMchoose, "questionID", strsql5, "tb_mchoose");
        string sql = "select * from tb_workexam where SubjectType='多选' and ExamID='" + ExamID + "'";
        conn.Open();
        SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, conn);
        DataSet dataset = new DataSet();
        dataAdapter.Fill(dataset, "tb_workexam");
        datatable = dataset.Tables["tb_workexam"];
        conn.Close();
        for (int i = 0; i < gvMchoose.Rows.Count; i++)
        {
            for (int j = 0; j < datatable.Rows.Count; j++)
            {
                //string eid = gvSchoose.Rows[i]["questionID"].ToString().Trim();
                if (gvMchoose.DataKeys[i].Value.ToString() == datatable.Rows[j]["questionID"].ToString())
                {
                    ((CheckBox)gvMchoose.Rows[i].FindControl("cbPitch")).Checked = true;
                    c++;
                    lblMchoose1.Text = c.ToString() + "题";
                }
            }
        }
    }
    //显示判断题以及选择情况
    public void gvJudge_Bind()
    {
        string strsql2 = "select * from tb_judge where courseID='" + cid + "'";
        BaseClass.BindDG(gvJudge, "questionID", strsql2, "tb_judge");
        string sql = "select * from tb_workexam where SubjectType='判断' and ExamID='" + ExamID + "'";
        conn.Open();
        SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, conn);
        DataSet dataset = new DataSet();
        dataAdapter.Fill(dataset, "tb_workexam");
        datatable = dataset.Tables["tb_workexam"];
        conn.Close();
        for (int i = 0; i < gvJudge.Rows.Count; i++)
        {
            for (int j = 0; j < datatable.Rows.Count; j++)
            {
                if (gvJudge.DataKeys[i].Value.ToString() == datatable.Rows[j]["questionID"].ToString())
                {
                    ((CheckBox)gvJudge.Rows[i].FindControl("cbPitch")).Checked = true;
                    d++;
                    lblJudge3.Text = d.ToString() + "题";
                }
            }
        }
    }
    //显示填空题以及选择情况
    public void gvInput_Bind()
    {
        string strsql3 = "select * from tb_input where courseID='" + cid + "'";
        BaseClass.BindDG(gvInput, "questionID", strsql3, "tb_input");
        string sql = "select * from tb_workexam where SubjectType='填空' and ExamID='" + ExamID + "'";
        conn.Open();
        SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, conn);
        DataSet dataset = new DataSet();
        dataAdapter.Fill(dataset, "tb_workexam");
        datatable = dataset.Tables["tb_workexam"];
        conn.Close();
        for (int i = 0; i < gvInput.Rows.Count; i++)
        {
            for (int j = 0; j < datatable.Rows.Count; j++)
            {
                if (gvInput.DataKeys[i].Value.ToString() == datatable.Rows[j]["questionID"].ToString())
                {
                    ((CheckBox)gvInput.Rows[i].FindControl("cbPitch")).Checked = true;
                    k++;
                    lblInput4.Text = k.ToString() + "题";
                }
            }
        }
    }
    //显示应用题以及选择情况
    public void gvApplication_Bind()
    {
        string strsql = "select * from tb_application where courseID='" + cid + "'";
        BaseClass.BindDG(gvApplication, "questionID", strsql, "tb_application");
        string sql = "select * from tb_workexam where SubjectType='应用' and ExamID='" + ExamID + "'";
        conn.Open();
        SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, conn);
        DataSet dataset = new DataSet();
        dataAdapter.Fill(dataset, "tb_workexam");
        datatable = dataset.Tables["tb_workexam"];
        conn.Close();
        for (int i = 0; i < gvApplication.Rows.Count; i++)
        {
            for (int j = 0; j < datatable.Rows.Count; j++)
            {
                if (gvApplication.DataKeys[i].Value.ToString() == datatable.Rows[j]["questionID"].ToString())
                {
                    ((CheckBox)gvApplication.Rows[i].FindControl("cbPitch")).Checked = true;
                    f++;
                    lblApplication5.Text = f.ToString() + "题";
                }
            }
        }
    }
    //计算选了几题单选题
    protected void cbPitch_CheckedChanged(object sender, EventArgs e)
    {
        for (int j = 0; j < gvSchoose.Rows.Count; j++)
        {
            if (((CheckBox)gvSchoose.Rows[j].FindControl("cbPitch")).Checked)
                b++;
            lblSchoose1.Text = b.ToString() + "题";
        }
    }
    //计算选了几题多选题
    protected void cbPitch_CheckedChanged1(object sender, EventArgs e)
    {
        for (int j = 0; j < gvMchoose.Rows.Count; j++)
            if (((CheckBox)gvMchoose.Rows[j].FindControl("cbPitch")).Checked)
                c++;
        lblMchoose1.Text = c.ToString() + "题";
    }
    //计算选了几题判断题
    protected void cbPitch_CheckedChanged2(object sender, EventArgs e)
    {
        for (int j = 0; j < gvJudge.Rows.Count; j++)
            if (((CheckBox)gvJudge.Rows[j].FindControl("cbPitch")).Checked)
                d++;
        lblJudge3.Text = d.ToString() + "题";
    }
    //计算选了几题填空题
    protected void cbPitch_CheckedChanged3(object sender, EventArgs e)
    {
        for (int j = 0; j < gvInput.Rows.Count; j++)
            if (((CheckBox)gvInput.Rows[j].FindControl("cbPitch")).Checked)
                k++;
        lblInput4.Text = k.ToString() + "题";
    }
    //计算选了几题应用题
    protected void cbPitch_CheckedChanged4(object sender, EventArgs e)
    {
        for (int j = 0; j < gvApplication.Rows.Count; j++)
            if (((CheckBox)gvApplication.Rows[j].FindControl("cbPitch")).Checked)
                f++;
        lblApplication5.Text = f.ToString() + "题";
    }
    //确定组卷 将选择的信息插入表中
    protected void btnOK_Click(object sender, EventArgs e)
    {
        //插入单选题
        conn.Open();
        ExamID = Request.QueryString["ExamID"];
        SqlCommand cmd121 = new SqlCommand("select * from tb_workexam where ExamID='" + ExamID + "' and SubjectType='单选'", conn);
        SqlDataReader sdr121 = cmd121.ExecuteReader();
        sdr121.Read();
        if (sdr121.HasRows)
        {
            string str22 = "delete from tb_workexam where ExamID='" + ExamID + "' and SubjectType='单选'";
            BaseClass.OperateData(str22);
            for (int i = 0; i < gvSchoose.Rows.Count; i++)
            {
                if (((CheckBox)gvSchoose.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvSchoose.DataKeys[i].Value).ToString().Trim());
                    string str = "INSERT INTO [xTest].[dbo].[tb_workexam]([ExamID], [questionID], [SubjectType],[CourseID])VALUES('" + Request.QueryString["ExamID"] + "','" + aa + "','单选','" + cid + "')";
                    BaseClass.OperateData(str);
                }
            } 
        }
        else
        {
            for (int i = 0; i < gvSchoose.Rows.Count; i++)
            {
                if (((CheckBox)gvSchoose.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvSchoose.DataKeys[i].Value).ToString().Trim());
                    conn.Close();
                    sdr121.Close();
string str1 = "INSERT INTO [xTest].[dbo].[tb_workexam]([ExamID], [questionID], [SubjectType],[CourseID])VALUES('" + Request.QueryString["ExamID"] + "','" + aa + "','单选','" + cid + "')";
                    BaseClass.OperateData(str1);
                }
            }
        }
        conn.Close();
        sdr121.Close();
        //插入多选题
                conn.Open();
        ExamID = Request.QueryString["ExamID"];
        SqlCommand cmd1211 = new SqlCommand("select * from tb_workexam where ExamID='" + ExamID + "' and SubjectType='多选'", conn);
        SqlDataReader sdr1211 = cmd1211.ExecuteReader();
        sdr1211.Read();
        if (sdr1211.HasRows)
        {
            string str22 = "delete from tb_workexam where ExamID='" + ExamID + "' and SubjectType='多选'";
            BaseClass.OperateData(str22);
            for (int i = 0; i < gvMchoose.Rows.Count; i++)
            {
                if (((CheckBox)gvMchoose.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvMchoose.DataKeys[i].Value).ToString().Trim());
                    string str = "INSERT INTO [xTest].[dbo].[tb_workexam]([ExamID], [questionID], [SubjectType],[CourseID])VALUES('" + Request.QueryString["ExamID"] + "','" + aa + "','多选','" + cid + "')";
                    BaseClass.OperateData(str);
                }
            }
        }
        else
        {
            for (int i = 0; i < gvMchoose.Rows.Count; i++)
            {
                if (((CheckBox)gvMchoose.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvMchoose.DataKeys[i].Value).ToString().Trim());
                    sdr1211.Close();
                    conn.Close();
                    string str = "INSERT INTO [xTest].[dbo].[tb_workexam]([ExamID], [questionID], [SubjectType],[CourseID])VALUES('" + Request.QueryString["ExamID"] + "','" + aa + "','多选','" + cid + "')";
                    BaseClass.OperateData(str);
                }
            }
        }
        sdr1211.Close();
        conn.Close();
        //插入判断题
            conn.Open();
        ExamID = Request.QueryString["ExamID"];
        SqlCommand cmd12 = new SqlCommand("select * from tb_workexam where ExamID='" + ExamID + "' and SubjectType='判断'", conn);
        SqlDataReader sdr12 = cmd12.ExecuteReader();
        sdr12.Read();
        if (sdr12.HasRows)
        {
            string str22 = "delete from tb_workexam where ExamID='" + ExamID + "' and SubjectType='判断'";
            BaseClass.OperateData(str22);
            for (int i = 0; i < gvJudge.Rows.Count; i++)
            {
                if (((CheckBox)gvJudge.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvJudge.DataKeys[i].Value).ToString().Trim());
                    string str = "update tb_workexam set questionID='" + aa + "' where SubjectType='判断' and ExamID='" + ExamID + "'";
                    BaseClass.OperateData(str);
                }
            }
            //Response.Write("<script lanuage=javascript>alert('完成修改！')</script>");
        }
        else
        {
            for (int i = 0; i < gvJudge.Rows.Count; i++)
            {
                if (((CheckBox)gvJudge.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvJudge.DataKeys[i].Value).ToString().Trim());
                    sdr12.Close();
                        conn.Close();
                        string str = "update tb_workexam set questionID='" + aa + "' where SubjectType='判断' and ExamID='" + ExamID + "'";
                        BaseClass.OperateData(str);
                }
            }
        }
        sdr12.Close();
        conn.Close();
        //插入填空题
        conn.Open();
        ExamID = Request.QueryString["ExamID"];
        SqlCommand cmd11 = new SqlCommand("select * from tb_workexam where ExamID='" + ExamID + "' and SubjectType='填空'", conn);
        SqlDataReader sdr11 = cmd11.ExecuteReader();
        sdr11.Read();
        if (sdr11.HasRows)
        {
            string str22 = "delete from tb_workexam where ExamID='" + ExamID + "' and SubjectType='填空'";
            BaseClass.OperateData(str22);
            for (int i = 0; i < gvInput.Rows.Count; i++)
            {
                if (((CheckBox)gvInput.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvInput.DataKeys[i].Value).ToString().Trim());
                    string str = "INSERT INTO [xTest].[dbo].[tb_workexam]([ExamID], [questionID], [SubjectType],[CourseID])VALUES('" + Request.QueryString["ExamID"] + "','" + aa + "','填空','" + cid + "')";
                    BaseClass.OperateData(str);
                }
            }
            //Response.Write("<script lanuage=javascript>alert('完成修改！')</script>");
        }
        else
        {
            for (int i = 0; i < gvInput.Rows.Count; i++)
            {
                if (((CheckBox)gvInput.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvInput.DataKeys[i].Value).ToString().Trim());
                    sdr11.Close();
                    conn.Close();
                    string str = "INSERT INTO [xTest].[dbo].[tb_workexam]([ExamID], [questionID], [SubjectType],[CourseID])VALUES('" + Request.QueryString["ExamID"] + "','" + aa + "','填空','" + cid + "')";
                    BaseClass.OperateData(str);
                }
            }
        }
        sdr11.Close();
        conn.Close();
        //插入应用题
        conn.Open();
        ExamID = Request.QueryString["ExamID"];
        SqlCommand cmd2 = new SqlCommand("select * from tb_workexam where ExamID='" + ExamID + "' and SubjectType='应用'", conn);       
        SqlDataReader sdr2 = cmd2.ExecuteReader();
        sdr2.Read();
        if (sdr2.HasRows)
        {

            string str22 = "delete from tb_workexam where ExamID='" + ExamID + "' and SubjectType='应用'";
            BaseClass.OperateData(str22); for (int i = 0; i < gvApplication.Rows.Count; i++)
            {
                if (((CheckBox)gvApplication.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvApplication.DataKeys[i].Value).ToString().Trim());
                    string act = "INSERT INTO [xTest].[dbo].[tb_workexam]([ExamID], [questionID], [SubjectType],[CourseID])VALUES('" + Request.QueryString["ExamID"] + "','" + aa + "','应用','" + cid + "')";
                    BaseClass.OperateData(act);
                }
            }
            Response.Write("<script lanuage=javascript>alert('完成修改！')</script>");
        }

        else
        {
            for (int i = 0; i < gvApplication.Rows.Count; i++)
            {
                if (((CheckBox)gvApplication.Rows[i].FindControl("cbPitch")).Checked)
                {
                    int aa = Int32.Parse((gvApplication.DataKeys[i].Value).ToString().Trim());

                    sdr2.Close();
                    conn.Close();
                    string act = "INSERT INTO [xTest].[dbo].[tb_workexam]([ExamID], [questionID], [SubjectType],[CourseID])VALUES('" + Request.QueryString["ExamID"] + "','" + aa + "','应用','" + cid + "')";
                    BaseClass.OperateData(act);
                }
            }
            Response.Write("<script lanuage=javascript>alert('完成抽卷！')</script>");
        }
        sdr2.Close();
        conn.Close();

    }
    public void btnSchoose_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = true;
        Panel4.Visible = false;
        Panel5.Visible = false;
        Panel6.Visible = false;
    }
    protected void btnMschoose_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel4.Visible = false;
        Panel5.Visible = false;
        Panel6.Visible = false;
    }
    protected void btnJudge_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel4.Visible = true;
        Panel5.Visible = false;
        Panel6.Visible = false;
    }
    protected void btninput_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel4.Visible = false;
        Panel5.Visible = true;
        Panel6.Visible = false;
    }
    protected void btnApplication_Click(object sender, EventArgs e)
    {
        Panel2.Visible = false;
        Panel4.Visible = false;
        Panel5.Visible = false;
        Panel6.Visible = true;
        Panel1.Visible = false;
    }
    protected void btnMchoose_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        Panel2.Visible = false;
        Panel4.Visible = false;
        Panel5.Visible = false;
        Panel6.Visible = false;
    }
}
