﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Teacher_ChangeApplication : System.Web.UI.Page
{
    string input = "";
    string str = "";
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["ExamID"] = Request.QueryString["ExamID"].ToString().Trim();
            datalist1bind();
        }
        SqlCommand cmd1 = new SqlCommand("select ApplicationPoint from tb_examInfo where ExamID='" + Session["ExamID"].ToString().Trim() + "'", conn);
        conn.Open();
        input = cmd1.ExecuteScalar().ToString();
        conn.Close();
        lblApplication.Text = "您改的是试卷编号为:(" + Session["ExamID"].ToString().Trim() + ")的试卷!该试卷的每小题为" + input + "分";
   }
    protected void datalist1bind()
    {
        string sqlconnstr = ConfigurationManager.ConnectionStrings["xTestConnectionString"].ConnectionString; ;
        DataSet ds = new DataSet();
        using (SqlConnection sqlconn = new SqlConnection(sqlconnstr))
        {
            SqlDataAdapter sqld = new SqlDataAdapter("select * from tb_studentexam where ExamID=" + Session["ExamID"].ToString().Trim(), sqlconn);
            sqld.Fill(ds, "tabstudent");
        }
        //以数据集中名为tabstudent的DataTable作为数据源，为控件绑定数据  
        DataList1.DataSource = ds.Tables["tabstudent"].DefaultView;
        DataList1.DataBind(); 
    }
    protected void btnApplication_Click(object sender, EventArgs e)
    {
        string str = "";
        float point=0;
        SqlConnection conn = BaseClass.DBCon();
        for (int i = 0; i < DataList1.Items.Count; i++)
        {
            str = ((Label)(DataList1.Items[i].FindControl("StudentIDLabel"))).Text.ToString().Trim();
            point += float.Parse(((TextBox)(DataList1.Items[i].FindControl("txtPoint"))).Text.ToString().Trim());
            SqlCommand OldCmd = new SqlCommand("select TotalResult from tb_examResult where StudentID='" + str + "'and ExamID='" + Session["ExamID"].ToString().Trim()+ "'", conn);
            conn.Open();

            float OldPoint = float.Parse(OldCmd.ExecuteScalar().ToString().Trim()) + point;
            string str1 = "UPDATE [xTest].[dbo].[tb_examResult] set ApplicationResult='" + point + "',TotalResult='" + OldPoint + "'where [StudentID]='" + str + "'and ExamID='" + Session["ExamID"].ToString().Trim()+"'";
            BaseClass.OperateData(str1);

            conn.Close();
            string str22 = "delete from tb_studentexam where StudentID='" + str + "'and ExamID='" + Session["ExamID"].ToString().Trim() + "'";
            BaseClass.OperateData(str22);
        }
        Response.Redirect("ChangeExam.aspx"); 
    }
    //protected void btnWin_Click(object sender, EventArgs e)
    //{      
    //    Panel1.Visible = true;
    //    for (int i = 0; i < DataList1.Items.Count; i++)
    //    {
    //        //Label SubjectIDLabel = (Label)(DataList1.Items[i].FindControl("StudentIDLabel"));         
    //        str = ((Label)(DataList1.Items[i].FindControl("SubjectIDLabel"))).Text.ToString().Trim();
    //        //SubjectIDLabel.Text = str;
    //        SqlCommand cmd = new SqlCommand("select questionText from tb_studentexam where ID='" + str + "'", conn);
    //        conn.Open();
    //        ((Label)(DataList1.Items[i].FindControl("lblSuject"))).Text = cmd.ExecuteScalar().ToString();
    //        conn.Close();
    //        ((Label)(DataList1.Items[i].FindControl("lblFullmark"))).Text = input;
    //    }
    //}
}
