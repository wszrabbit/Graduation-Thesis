﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_adminresult : System.Web.UI.Page
{
    SqlConnection conn = BaseClass.DBCon();
    string cid;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select courseID from tb_teacher where teacherID='" + Session["teacherID"].ToString() + "'", conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            cid = sdr["courseID"].ToString();
            conn.Close();
            string str = "select * from tb_examResult where courseID='" + cid + "'";
            BaseClass.BindDG(GridView1, "ID", str, "result");
            //conn.Close();
        }
    }
    protected void btncx_Click(object sender, EventArgs e)
    {
        if (tbx_query.Text == "")
        {
            string strsql = "select * from tb_examResult where courseID='"+ cid +"'";
            BaseClass.BindDG(GridView1, "ID", strsql, "stuinfo");
        }
        else
        {
            string stype = DropDownList1.SelectedItem.Text;
            string strsql = "";  
            switch (stype)
            {
                case "学生编号":
                    strsql = "select * from tb_examResult where StudentID like '%" + tbx_query.Text.Trim() + "%'";
                    BaseClass.BindDG(GridView1, "ID", strsql, "stuinfo"); ;
                    break;
                case "考试班级":
                    //string sql = "slesct ClassName from tb_class";
                    conn.Open();
                    SqlCommand cmd1 = new SqlCommand("select ClassID from tb_class where ClassName = '" + tbx_query.Text.Trim() + "'", conn);
                    SqlDataReader sdr1 = cmd1.ExecuteReader();
                    sdr1.Read();
                    string c = sdr1["ClassID"].ToString();
                    conn.Close();
                    strsql = "select * from tb_examResult where StudentID like'%" + c + "%'";
                    BaseClass.BindDG(GridView1, "ID", strsql, "stuinfo");
                    break;
                case "总成绩":
                    strsql = "select * from tb_examResult where TotalResult like '%" + tbx_query.Text.Trim() + "%'";
                    BaseClass.BindDG(GridView1, "ID", strsql, "stuinfo");
                    break;

            }
        }
    }
    protected void link_Click(object sender, EventArgs e)
    {
        RegisterStartupScript("提示", "<script>window.close();</script>");
        //Response.Redirect("Login.aspx");
    }
}
