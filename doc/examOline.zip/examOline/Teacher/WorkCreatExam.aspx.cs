﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Teacher_WorkCreatExam : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GridView1_Bind();
        }
    }
    public void GridView1_Bind()
    {
        SqlConnection conn = BaseClass.DBCon();
        conn.Open();
        SqlCommand cmd = new SqlCommand("select courseID from tb_teacher where teacherID='" + Session["teacherID"].ToString() + "'", conn);
        SqlDataReader sdr = cmd.ExecuteReader();
        sdr.Read();
       string courseid = sdr["courseID"].ToString();
        conn.Close();
        string strsql = "select * from tb_ExamInfo where courseID='" + courseid + "'";
        BaseClass.BindDG(GridView1, "ExamID", strsql, "tb_ExamInfo");

        conn.Open();
        SqlCommand cmd1 = new SqlCommand("select * from tb_ExamInfo", conn);
        SqlDataReader sdr1 = cmd1.ExecuteReader(); 
        conn.Close();
    }
    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        GridView1_Bind();
    }
}
