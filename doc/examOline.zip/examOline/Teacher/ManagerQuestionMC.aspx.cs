﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Teacher_ManagerQuestionMC : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["teacherID"] == null)
        //{
        //    Response.Redirect("../Login.aspx");
        //}
        if (!IsPostBack)
        {
            gvExaminationInfo_Bind();
        }
    }

    public void gvExaminationInfo_Bind()
    {
        //将登陆的教师所教课程的多选题在表中显示
        //string teacherid = Session["teacherID"].ToString();
        SqlConnection conn1 = BaseClass.DBCon();
        conn1.Open();
        SqlCommand cmd1 = new SqlCommand("select * from tb_teacher where teacherID='" + Session["teacherID"].ToString() + "'", conn1);
        SqlDataReader sdr1 = cmd1.ExecuteReader();
        sdr1.Read();
        Label1.Text = sdr1["courseID"].ToString();
        conn1.Close();
        //Session["courseID"] = Label1.Text;
        string strsql = "select * from tb_mchoose where courseID='" + Label1.Text + "'";
        BaseClass.BindDG(gvExaminationInfo, "questionID", strsql, "tb_mchoose");
        SqlConnection conn = BaseClass.DBCon();
        conn.Open();
        SqlCommand cmd = new SqlCommand("select * from tb_mchoose", conn);
        SqlDataReader sdr = cmd.ExecuteReader();
      
        //this.ddlEkm.DataSource = sdr;
        //this.ddlEkm.DataTextField = "courseID";
        //this.ddlEkm.DataValueField = "ID";
        //this.ddlEkm.DataBind();
        conn.Close();
    }
    protected void gvExaminationInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvExaminationInfo.PageIndex = e.NewPageIndex;
        gvExaminationInfo_Bind();
    }
    protected void btnSerch_Click(object sender, EventArgs e)
    {
        //string s = ddlEkm.SelectedItem.Text;
        //if (s == "是")
        //{

        //}
        ////lbltype.Text = ddlEkm.SelectedItem.Text.Trim();
        //string strsql = "select * from tb_mchoose where courseID ='" + ddlEkm.SelectedItem.Text.Trim() + "'";
        ////BaseClass.BindDG(gvExaminationInfo, "ID", strsql, "SingleChooseInfo");
        //SqlConnection conn = BaseClass.DBCon();
        //conn.Open();
        //SqlCommand cmd = new SqlCommand("select * from tb_mchoose", conn);
        //SqlDataReader sdr = cmd.ExecuteReader();
        //this.ddlEkm.DataSource = sdr;
        //this.ddlEkm.DataTextField = "courseID";
        //this.ddlEkm.DataValueField = "ID";
        //this.ddlEkm.DataBind();
        //conn.Close();
        Response.Redirect("AddQuestionMC.aspx");
    }
}
