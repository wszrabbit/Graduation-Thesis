﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_AddAdminInfo : System.Web.UI.Page
{
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["admin"] == null)
        //{
        //    Response.Redirect("../Login.aspx");
        //}
        if (!IsPostBack)
        {
            conn.Open();
            string str = "select top 1 courseID from tb_course order by courseID DESC";
            SqlCommand cmd1 = new SqlCommand(str, conn);
            int count = Convert.ToInt32(cmd1.ExecuteScalar());
            int newid = count + 1;
            txtID.Text = newid.ToString();
            conn.Close();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        string str = "insert into tb_course (courseID,courseName)  values('" + txtID.Text.Trim() + "','" + txtName.Text.Trim() + "' )";
        BaseClass.OperateData(str);
        Response.Redirect("CourseInfo.aspx");
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clear();
    }
    protected void Clear()
    { 
        txtName.Text="";
       
    }
}
