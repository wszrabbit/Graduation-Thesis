﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_professionalUpdate : System.Web.UI.Page
{
    string id;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            id = Request.QueryString["ProfessionalID"].ToString();
            SqlConnection conn = BaseClass.DBCon();
          
            conn.Open();
            SqlCommand cmd1 = new SqlCommand("select * from tb_professional where ProfessionalID=" + id, conn);
            SqlDataReader sdr1 = cmd1.ExecuteReader();
            while (sdr1.Read())
            {
                proN.Text = sdr1["ProfessionalName"].ToString();
                proId.Text = sdr1["ProfessionalID"].ToString();
                proD.SelectedValue = sdr1["DepartmentID"].ToString();
            }
            conn.Close();
            string str = "select * from tb_department";
            BaseClass.BindDDL(proD, "DepartmentName", "DepartmentID", str, "tb_department");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("professionalInfoView.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (proN.Text.Trim() == "")
        {

            Label1.Text = "请将专业名称填写完整。";
            return;
        }
        else
        {
            id = Request.QueryString["ProfessionalID"].ToString();
            string str = "update tb_professional set ProfessionalName='" + proN.Text.Trim() + "',DepartmentID='" + proD.SelectedValue + "' where ProfessionalID='" + id + "'";
            BaseClass.OperateData(str);
            //SqlConnection conn = BaseClass.DBCon();
            //conn.Open();
            //SqlCommand cmd = new SqlCommand(str, conn);
            //cmd.ExecuteNonQuery();
            //conn.Close();

        }
        Response.Redirect("professionalInfoView.aspx");
    }
}
