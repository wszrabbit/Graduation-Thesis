﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_classUpdate : System.Web.UI.Page
{
    string id;
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            id = Request.QueryString["ClassID"].ToString();
            string str2 = "select * from tb_department";
            BaseClass.BindDDL(DDlatt, "DepartmentName", "DepartmentID", str2, "tb_department");

            string str1 = "select * from tb_professional";
            BaseClass.BindDDL(DDlpsl, "ProfessionalName", "ProfessionalID", str1, "tb_professional");        
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_class where ClassID=" + id, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                DDlatt.SelectedValue = sdr["DepartmentID"].ToString();
                DDlpsl.SelectedValue = sdr["ProfessionalID"].ToString();
           txtclsNum.Text=sdr["ClassName"].ToString();
                txtclsID.Text =id;
            }
            conn.Close();
            
        }
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {
        if (txtclsNum.Text.Trim() == "")
        {
            lblMessage.Text = "请将班级名填写完整。";
            return;
        }
        else
        {

            id = Request.QueryString["ClassID"].ToString();
            string str = "update tb_class set ClassName='" + txtclsNum.Text.Trim() + "',DepartmentID='" + DDlatt.SelectedValue +
           "',ProfessionalID='" + DDlpsl.SelectedValue + "' where ClassID='" + id + "'";
            BaseClass.OperateData(str);
            Response.Redirect("classInfoView.aspx");
        }
    }
    protected void btnEsc_Click(object sender, EventArgs e)
    {
        Response.Redirect("classInfoView.aspx");
    }
}