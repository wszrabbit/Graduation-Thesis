﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_departmentInfoView : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string strsql = "select * from tb_department order by DepartmentID desc";
            BaseClass.BindDG(gvDepartmInfo, "DepartmentID", strsql, "departmInfo");
        }
    }
    //显示院系信息
    protected void gvDepartmInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvDepartmInfo.PageIndex = e.NewPageIndex;
        string strsql = "select * from tb_department order by DepartmentID desc";
        BaseClass.BindDG(gvDepartmInfo, "DepartmentID", strsql, "departminfo");
    }
//删除院系信息
    protected void gvDepartmInfo_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int id = (int)gvDepartmInfo.DataKeys[e.RowIndex].Value;
        string str = "delete from tb_department where DepartmentID=" + id;
        BaseClass.OperateData(str);
        string str1 = "delete from tb_professional where DepartmentID=" + id;
        BaseClass.OperateData(str1);
        string str2 = "delete from tb_class where DepartmentID=" + id;
        BaseClass.OperateData(str2);
        string strsql = "select * from tb_department order by DepartmentID desc";
        BaseClass.BindDG(gvDepartmInfo, "DepartmentID", strsql, "departminfo");
    }
    //按条件查找院系信息
    protected void Button6_Click(object sender, EventArgs e)
    {
        if (depm_query.Text == "")
        {
            string strsql = "select * from tb_department order by DepartmentID desc";
            BaseClass.BindDG(gvDepartmInfo, "DepartmentID", strsql, "departmInfo");
        }
        else
        {
            string stype = D1.SelectedItem.Text;
            string strsql = "";
            switch (stype)
            {
                case "院系编号":
                    strsql = "select * from tb_department where DepartmentID like '%" + depm_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvDepartmInfo, "DepartmentID", strsql, "departmInfo"); ;
                    break;
                case "院系名称":
                    strsql = "select * from tb_department where DepartmentName like '%" + depm_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvDepartmInfo, "DepartmentID", strsql, "departmInfo");
                    break;
            }
        }
    }
}