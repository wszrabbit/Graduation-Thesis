﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_professionalInfoView : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string strsql = "select * from tb_professional order by ProfessionalID desc";
            BaseClass.BindDG(gvPofessInfo, "ProfessionalID", strsql, "departmInfo");
        }
    }
    //显示院系信息
    protected void gvPofessInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvPofessInfo.PageIndex = e.NewPageIndex;
        string strsql = "select * from tb_professional order by ProfessionalID desc";
        BaseClass.BindDG(gvPofessInfo, "ProfessionalID", strsql, "departminfo");
    }
    //删除院系信息
    protected void gvPofessInfo_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Response.Redirect("professionalDel.aspx");
        
    }
    //按条件查找院系信息
    protected void Button6_Click(object sender, EventArgs e)
    {
        if (profess_query.Text == "")
        {
            string strsql = "select * from tb_professional order by ProfessionalID desc";
            BaseClass.BindDG(gvPofessInfo, "ProfessionalID", strsql, "departmInfo");
        }
        else
        {
            string stype = DropDownList1.SelectedItem.Text;
            string strsql = "";
            switch (stype)
            {
                case "专业编号":
                    strsql = "select * from tb_professional where ProfessionalID like '%" + profess_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvPofessInfo, "ProfessionalID", strsql, "departmInfo"); ;
                    break;
                case "专业名称":
                    strsql = "select * from tb_professional where ProfessionalName like '%" + profess_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvPofessInfo, "ProfessionalID", strsql, "departmInfo");
                    break;
                case "所属院系":
                    strsql = "select * from tb_professional where DepartmentID like '%" + profess_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvPofessInfo, "ProfessionalID", strsql, "departmInfo");
                    break;
            }
        }
    }
}