﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Addclass : System.Web.UI.Page
{
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //string str = "select * from tb_teacher";
            //BaseClass.BindDDL(DDltcr, "TeacherName", "TeacherID", str, "tb_teacher"); 
        //int id1 = int.Parse(Session["ProfessionalID"].ToString());
        string str2 = "select * from tb_department";
        BaseClass.BindDDL(DDlatt, "DepartmentName", "DepartmentID", str2, "tb_department");

        string str1 = "select * from tb_professional";
        BaseClass.BindDDL(DDlpsl, "ProfessionalName", "ProfessionalID", str1, "tb_professional");
 
        conn.Open();
        string str = "select top 1 ClassID from tb_class order by ClassID DESC";
        SqlCommand cmd1 = new SqlCommand(str, conn);
        int count = Convert.ToInt32(cmd1.ExecuteScalar());
        int newid = count + 1;
        txtclsID.Text = newid.ToString();
        conn.Close();
        }
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {
       //将数据插入表中
        string str = "insert into tb_class(ClassID,ClassName,ProfessionalID,DepartmentID)  values('" + txtclsID.Text.Trim() + "','" + txtclsNum.Text.Trim() + "','" + DDlpsl.SelectedValue.Trim() + "','" + DDlatt.SelectedValue.Trim() + "')";
        SqlCommand cmd1 = new SqlCommand(str, conn);
        conn.Open();
        SqlDataReader reader = cmd1.ExecuteReader();
        while (reader.Read())
        {
            Response.Write("<script>alert('插入成功！');</script>");
        }
        conn.Close();
        Response.Redirect("classInfoView.aspx");
    }
    protected void btnEsc_Click(object sender, EventArgs e)
    {
        Response.Redirect("classInfoView.aspx");
    }
}
