﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_ManagerExamInfo : System.Web.UI.Page
{
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string str = "select * from tb_ExamInfo order by ExamID desc";
            BaseClass.BindDG(gvExaminationInfo, "ExamID", str, "result");
        }
    }
    protected void btncx_Click(object sender, EventArgs e)
    {
        if (tbx_query.Text == "")
        {
            string strsql = "select * from tb_ExamInfo order by ExamID desc";
            BaseClass.BindDG(gvExaminationInfo, "ExamID", strsql, "stuinfo");
        }
        else
        {
            string stype = DropDownList1.SelectedItem.Text;
            string strsql = "";
            switch (stype)
            {
                case "试卷编号":
                    strsql = "select * from tb_ExamInfo where ExamID like '%" + tbx_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvExaminationInfo, "ExamID", strsql, "stuinfo"); ;
                    break;
                case "考试截止时间":
                    strsql = "select * from tb_ExamInfo where EndTime like '%" + tbx_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvExaminationInfo, "ExamID", strsql, "stuinfo");
                    break;

            }
        }
    }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        for (int i = 0; i <= gvExaminationInfo.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)gvExaminationInfo.Rows[i].FindControl("CheckBox1");
            if (CheckBox2.Checked == true)
            {
                cbox.Checked = true;
            }
            else
            {
                cbox.Checked = false;
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        CheckBox2.Checked = false;
        for (int i = 0; i <= gvExaminationInfo.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)gvExaminationInfo.Rows[i].FindControl("CheckBox1");
            cbox.Checked = false;
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        conn.Open();
        for (int i = 0; i <= gvExaminationInfo.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)gvExaminationInfo.Rows[i].FindControl("CheckBox1");
            if (cbox.Checked == true)
            {
                string str = "delete from tb_ExamInfo where ExamID='" + gvExaminationInfo.DataKeys[i].Value + "'";
                BaseClass.OperateData(str);
                string str1 = "delete from tb_workexam where ExamID='" + gvExaminationInfo.DataKeys[i].Value + "'";
                BaseClass.OperateData(str1);
                BaseClass.BindDG(gvExaminationInfo, "ExamID", str, "result");
                conn.Close();
                Response.Redirect("ManagerExamInfo.aspx");
            }
        }

    }
}