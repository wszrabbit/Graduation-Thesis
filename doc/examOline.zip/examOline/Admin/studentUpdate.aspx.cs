﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_studentUpdate : System.Web.UI.Page
{
    string id;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            id = Request.QueryString["StudentID"].ToString();
            SqlConnection conn = BaseClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_Student where studentID=" + id, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                tbx_stuName.Text = sdr["StudentName"].ToString();
                tbx_stuId.Text = sdr["StudentID"].ToString();
                tbx_stuPwd.Text = sdr["StudentPwd"].ToString();
                ddlClass.SelectedValue=sdr["ClassID"].ToString();
                rblSex.SelectedValue = sdr["Sex"].ToString().Trim();
            }
            conn.Close();
            string str = "select * from tb_class";
            BaseClass.BindDDL(ddlClass, "ClassName", "ClassID", str, "tb_class");
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("stuInfoView.aspx");
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (tbx_stuName.Text.Trim() == "" || tbx_stuPwd.Text.Trim() == "")
        {
            
            Label1.Text = "请将姓名和密码信息填写完整。";
            return;
        }
        else
        {
            id = Request.QueryString["StudentID"].ToString();

            string str = "update tb_Student set StudentName='" + tbx_stuName.Text.Trim() + "',StudentPwd='"
            + tbx_stuPwd.Text.Trim() + "',Sex='" +rblSex.SelectedValue +
           "',ClassID='" + ddlClass.SelectedValue  +
            "' where studentID='" + id + "'";
            BaseClass.OperateData(str);          
        }
        Response.Redirect("stuInfoView.aspx");
    }
    protected void ddlClass_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
