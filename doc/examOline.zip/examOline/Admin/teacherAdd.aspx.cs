﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_teacherAdd : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            SqlConnection conn = BaseClass.DBCon();
            conn.Open();
            string cmdStr = "select * from tb_teacher ";

            SqlCommand cmdDDL = new SqlCommand(cmdStr, conn);
            SqlDataReader sdrDDL = cmdDDL.ExecuteReader();
            conn.Close();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_course", conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            this.ddlEkm.DataSource = sdr;
            this.ddlEkm.DataTextField = "courseName";
            this.ddlEkm.DataValueField = "courseID";
            this.ddlEkm.DataBind();
            conn.Close();
            string str1 = "select top 1 teacherID from tb_teacher order by teacherID DESC";
            conn.Open();
            SqlCommand cmd1 = new SqlCommand(str1, conn);
            int count = Convert.ToInt32(cmd1.ExecuteScalar());
            int newid = count + 1;
            txtID.Text = newid.ToString();
            conn.Close();
        }
    }
    protected void btncen_Click(object sender, EventArgs e)
    {
        txtname.Text = "";
        //rblroler.SelectedIndex = -1;
        rblsex.SelectedIndex = -1;
    }
    protected void btnok_Click(object sender, EventArgs e)
    {
        SqlConnection conn = BaseClass.DBCon();
        conn.Open();
        string str = "insert into tb_teacher(TeacherID,TeacherName,TeacherPwd,Sex,courseID)  values('" + txtID.Text.Trim() + "','" + txtname.Text.Trim() + "','" + txtpwd.Text.Trim() + "','" + rblsex.SelectedItem.Text + "','" + ddlEkm.SelectedValue + "')";
        BaseClass.OperateData(str);
        Response.Redirect("teacherInfoView.aspx");
    }
}
