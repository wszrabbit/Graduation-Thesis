﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Data.OleDb;
public partial class Admin_classInfoView : System.Web.UI.Page
{
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string strsql = "select * from tb_class order by classID desc";
            BaseClass.BindDG(gvClassInfo, "classID", strsql, "classInfo");
        }
    }
    protected void gvClassInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvClassInfo.PageIndex = e.NewPageIndex;
        string strsql = "select * from tb_class order by classID desc";
        BaseClass.BindDG(gvClassInfo, "classID", strsql, "stuinfo");
    }
    //删除班级以及与班级相关联的学生信息
    protected void Button2_Click(object sender, EventArgs e)
    {
        for (int i = 0; i <= gvClassInfo.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)gvClassInfo.Rows[i].FindControl("CheckBox1");
            if (cbox.Checked == true)
            {
                string str = "delete from tb_Student where ClassID='" + gvClassInfo.DataKeys[i].Value + "'";
                BaseClass.OperateData(str);
                string str2 = "delete from tb_class where ClassID='" + gvClassInfo.DataKeys[i].Value + "'";
                BaseClass.OperateData(str2);
                string str3 = "delete from tb_studentexam where StudentID like '%" + gvClassInfo.DataKeys[i].Value + "%'";
                BaseClass.OperateData(str3);
                string str4 = "delete from tb_examResult where StudentID like '%" + gvClassInfo.DataKeys[i].Value + "%'";
                BaseClass.OperateData(str4);
            }
        }
        Response.Redirect("classInfoView.aspx");
    }
    //按条件查找班级信息
    protected void Button6_Click(object sender, EventArgs e)
    {
        if (class_query.Text == "")
        {
            string strsql = "select * from tb_class order by classID desc";
            BaseClass.BindDG(gvClassInfo, "classID", strsql, "classInfo");
        }
        else
        {
            string stype = DropDownList1.SelectedItem.Text;
            string strsql = "";
            switch (stype)
            {
                case "班级编号":
                    strsql = "select * from tb_class where ClassID like '%" + class_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvClassInfo, "classID", strsql, "classInfo"); ;
                    break;
                case "班级名称":
                    strsql = "select * from tb_class where ClasslName like '%" + class_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvClassInfo, "classID", strsql, "classInfo");
                    break;
                case "所属院系":
                    strsql = "select * from tb_class where DepartmentID like '%" + class_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvClassInfo, "classID", strsql, "classInfo");
                    break;
                case "所属专业":
                    strsql = "select * from tb_class where ProfessionalID like '%" + class_query.Text.Trim() + "%'";
                    BaseClass.BindDG(gvClassInfo, "classID", strsql, "classInfo");
                    break;
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        CheckBox2.Checked = false;
        for (int i = 0; i <= gvClassInfo.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)gvClassInfo.Rows[i].FindControl("CheckBox1");
            cbox.Checked = false;
        }
    }
    protected void CheckBox2_CheckedChanged(object sender, EventArgs e)
    {
        for (int i = 0; i <= gvClassInfo.Rows.Count - 1; i++)
        {
            CheckBox cbox = (CheckBox)gvClassInfo.Rows[i].FindControl("CheckBox1");
            if (CheckBox2.Checked == true)
            {
                cbox.Checked = true;
            }
            else
            {
                cbox.Checked = false;
            }
        }
    }
    public DataSet ExecleDs(string filenameurl, string table)
    {
        string strConn = "Provider=Microsoft.Jet.OleDb.4.0;" + "data source=" + filenameurl + ";Extended Properties='Excel 8.0; HDR=YES; IMEX=1'";
        OleDbConnection conn = new OleDbConnection(strConn);
        conn.Open();
        DataSet ds = new DataSet();
        OleDbDataAdapter odda = new OleDbDataAdapter("select * from [Sheet1$]", conn);
        odda.Fill(ds, table);
        return ds;
    }
    protected void bt_in_Click(object sender, EventArgs e)
    {

        string ci = "", cn = "",di = "", pi = "";
        if (FileUpload1.HasFile == false)//HasFile用来检查FileUpload是否有指定文件
        {
            Response.Write("<script>alert('请您选择Excel文件')</script> ");
            return;//当无文件时,返回
        }
        string IsXls = System.IO.Path.GetExtension(FileUpload1.FileName).ToString().ToLower();//System.IO.Path.GetExtension获得文件的扩展名
        if (IsXls != ".et")
        {
            Response.Write("<script>alert('只可以选择Excel文件')</script>");
            return;//当选择的不是Excel文件时,返回
        }
        conn.Open();
        string filename = DateTime.Now.ToString("yyyymmddhhMMss") + FileUpload1.FileName;              //获取Execle文件名  DateTime日期函数
        string savePath = Server.MapPath(("upfiles\\") + filename);//Server.MapPath 获得虚拟服务器相对路径
        FileUpload1.SaveAs(savePath);                        //SaveAs 将上传的文件内容保存在服务器上
        DataSet ds = ExecleDs(savePath, filename);           //调用自定义方法
        DataRow[] dr = ds.Tables[0].Select();            //定义一个DataRow数组
        int rowsnum = ds.Tables[0].Rows.Count;
        if (rowsnum == 0)
        {
            Response.Write("<script>alert('Excel表为空表,无数据!')</script>");   //当Excel表为空时,对用户进行提示
        }
        else
        {
            for (int i = 0; i < dr.Length; i++)
            {
                try
                {
                    ci = dr[i]["班级编号"].ToString();//日期 excel列名【名称不能变,否则就会出错】
                    cn = dr[i]["班级名称"].ToString();//编号 列名 以下类似
                    di = dr[i]["所属院系编号"].ToString();
                    pi = dr[i]["所属专业编号"].ToString();
                }
                catch
                {
                    this.Response.Write("<script language='javascript'>alert('对不起，您导入的excel有错，请检查！');window.parent.hsgmain.location='classInfoView.aspx';</script>");   //跳转到原来页面
                }

                string sqlcheck = "select count(*) from tb_class where ClassID='" + ci + "'";  //检查用户是否存在
                SqlCommand sqlcmd = new SqlCommand(sqlcheck, conn);
                int count = Convert.ToInt32(sqlcmd.ExecuteScalar());
                if (count < 1)
                {
                    string insertstr = "insert into tb_class(ClassID,ClassName,ProfessionalID,DepartmentID) values('" + ci + "','" + cn + "','" + pi + "','" + di + "')";

                    SqlCommand cmd = new SqlCommand(insertstr, conn);
                    cmd.ExecuteNonQuery();

                }
                else
                {
                    Response.Write("<script>alert('用户id重复！禁止导入');location='classInfoView.aspx'</script></script> ");
                    continue;
                }
            }
            Response.Write("<script>alert('Excle表导入成功!');location='classInfoView.aspx'</script>");
        }
        conn.Close();
    }
}