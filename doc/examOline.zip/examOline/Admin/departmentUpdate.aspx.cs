﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_departmentUpdate : System.Web.UI.Page
{
    string id;
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["admin"] == null)
        //{
        //    Response.Redirect("../Login.aspx");
        //}
        if (!IsPostBack)
        {
            id = Request.QueryString["DepartmentID"].ToString();
            SqlConnection conn = BaseClass.DBCon();
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_department where DepartmentID=" + id, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                TextBox1.Text = sdr["DepartmentName"].ToString();
                txtddtID.Text = sdr["DepartmentID"].ToString();
            }
            conn.Close();
        }
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text.Trim() == "")
        {
            lblMessage.Text = "请将课程名称填写完整。";
            return;
        }
        else
        {
            //调试备忘，一定要重新获取id值，不知为何?
            id = Request.QueryString["DepartmentID"].ToString();
            string str = "update tb_department set DepartmentName='" + TextBox1.Text.Trim() + "' where DepartmentID='" + id + "'";
            BaseClass.OperateData(str);
            Response.Redirect("departmentInfoView.aspx");
        }
    }
    protected void btnEsc_Click(object sender, EventArgs e)
    {
        Response.Redirect("departmentInfoView.aspx");
    }
}
