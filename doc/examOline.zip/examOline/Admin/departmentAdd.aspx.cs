﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin_Adddepartment : System.Web.UI.Page
{
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
       if (!IsPostBack)
     {
      //    string str = "select * from tb_teacher";
      //      BaseClass.BindDDL(ddl, "TeacherName", "TeacherID", str, "tb_teacher");
      }
       conn.Open();
       string str1 = "select top 1 DepartmentID from tb_department order by DepartmentID DESC";
       SqlCommand cmd = new SqlCommand(str1, conn);
       int count = Convert.ToInt32(cmd.ExecuteScalar());
       int newid = count + 1;
       txtddtID.Text = newid.ToString();
       conn.Close();
    }
    protected void btnOK_Click(object sender, EventArgs e)
    {
        string str = "insert into tb_department(DepartmentID,DepartmentName)  values('" + txtddtID.Text.Trim() + "','" + TextBox1.Text.Trim() + "')";
        SqlCommand cmd1 = new SqlCommand(str,conn);
        conn.Open();
        SqlDataReader reader=cmd1.ExecuteReader ();
        while (reader.Read())
        {
            Response.Write("<script>alert('插入成功！');</script>");
        }
        conn.Close();
        Response.Redirect("departmentInfoView.aspx");
    }
    protected void btnEsc_Click(object sender, EventArgs e)
    {
        
        //txtddtID.Text = "";
        //txtDtn.Text = "";
        TextBox1.Text = "";
    }
}
