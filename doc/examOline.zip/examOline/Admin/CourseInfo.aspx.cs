﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_AdminInfo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string strsql = "select * from tb_course order by courseID desc";
            BaseClass.BindDG(gvAdmInfo, "courseID", strsql, "admInfo");
        }

    }
    protected void btnserch_Click(object sender, EventArgs e)
    {

        if (txtKey.Text == "")
        {
            string strsql = "select * from tb_course order by courseID desc";
            BaseClass.BindDG(gvAdmInfo, "courseID", strsql, "admInfo");
        }
        else
        {
            string stype = ddlType.SelectedItem.Text;
            string strsql = "";
            switch (stype)
            {
                case "课程编号":
                    strsql = "select * from tb_course where courseID like '%" + txtKey.Text.Trim() + "%'";
                    BaseClass.BindDG(gvAdmInfo, "courseID", strsql, "admInfo"); ;
                    break;
                case "课程名称":
                    strsql = "select * from tb_course where courseName like '%" + txtKey.Text.Trim() + "%'";
                    BaseClass.BindDG(gvAdmInfo, "courseID", strsql, "admInfo");
                    break;
            }
        }
    }

    protected void gvAdmInfo_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int id = (int)gvAdmInfo.DataKeys[e.RowIndex].Value;
        string str = "delete from tb_course where courseID=" + id;
        BaseClass.OperateData(str);
        string str1 = "delete from tb_teacher where courseID=" + id;
        BaseClass.OperateData(str1);
        string strsql = "select * from tb_course order by courseID desc";
        BaseClass.BindDG(gvAdmInfo, "courseID", strsql, "adminfo");
    }
    protected void gvAdmInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvAdmInfo.PageIndex = e.NewPageIndex;
        string strsql = "select * from tb_course order by courseID desc";
        BaseClass.BindDG(gvAdmInfo, "courseID", strsql, "adminfo");
    }
}
