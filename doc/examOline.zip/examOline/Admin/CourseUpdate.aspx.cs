﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Admin_ChangeAdminInfo : System.Web.UI.Page
{
    string id;
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Session["admin"] == null)
        //{
        //    Response.Redirect("../Login.aspx");
        //}
        if (!IsPostBack)
        {
            id = Request.QueryString["courseID"].ToString();
            SqlConnection conn = BaseClass.DBCon();  
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from tb_course where courseID=" + id, conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                txtAdminName.Text = sdr["courseName"].ToString();
                txtAdminID.Text = sdr["courseID"].ToString();
            }
            conn.Close();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        if (txtAdminName.Text.Trim() == "" )
        {
            lblMessage.Text = "请将课程名称填写完整。";
            return;
        }
        else
        {
            //调试备忘，一定要重新获取id值，不知为何?
            id = Request.QueryString["courseID"].ToString();
            string str = "update tb_course set courseName='" + txtAdminName.Text.Trim() + "' where courseID='" + id + "'";
            BaseClass.OperateData(str);
            Response.Redirect("CourseInfo.aspx");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("CourseInfo.aspx");
    }
}
