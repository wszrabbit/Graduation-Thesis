﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Student_text : System.Web.UI.Page
{
    string sm;//单选题题数
    string mm;//多选题题数
    string im;//填空题题数
    string jm;//判断题题数
    string am;//应用题题数
    string studentid;
    DateTime t1;
    DateTime t2;
    DateTime t3;
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            studentid = Session["StudentID"].ToString();      
            conn.Open();
            SqlCommand cmd = new SqlCommand("select ClassID from tb_student where StudentID='" + studentid + "'", conn);
            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            string classid = sdr["ClassID"].ToString();
            conn.Close();

            conn.Open();
            SqlCommand cmd2 = new SqlCommand("select * from tb_ExamInfo where ClassID='" + classid + "'", conn);
            SqlDataReader sdr2 = cmd2.ExecuteReader();
            while (sdr2.Read())
            {
                Label10.Text = sdr2["ExamID"].ToString();
                Label11.Text = sdr2["courseID"].ToString();
                Label12.Text = sdr2["SChoosePoint"].ToString();
                Label13.Text = sdr2["InputPoint"].ToString();
                Label14.Text = sdr2["MChoosePoint"].ToString();
                Label15.Text = sdr2["JudgePoint"].ToString();
                Label16.Text = sdr2["ApplicationPoint"].ToString();
                sm = sdr2["SChooseNum"].ToString();
                mm = sdr2["MChooseNum"].ToString();
                im = sdr2["InputNum"].ToString();
                jm = sdr2["JudgeNum"].ToString();
                am = sdr2["ApplicationNum"].ToString();
                DateTime today = System.DateTime.Now;
                string t = sdr2["StartTime"].ToString();
                string et = sdr2["EndTime"].ToString();
                string tow = today.ToString().Trim();
                t1 = DateTime.Parse(tow);
                 t2 = DateTime.Parse(t);
                t3 = DateTime.Parse(et);
            }
            if (sm == "0")
        {
            btnSchoose.Visible = false;
        }
                    if (mm == "0")
        {
            btnMchoose.Visible = false;
        }
        if (im == "0")
        {
            btnInput.Visible = false;  
        }
        if (jm == "0")
        {
            btnJudge.Visible = false;      
        }
        if (am == "0")
        {
            btnApplication.Visible = false;          
        }
            conn.Close();
            if (DateTime.Compare(t1,t2)>=0 && DateTime.Compare(t1,t3)<=0)
            {
                conn.Open();
                SqlCommand cmd3 = new SqlCommand("select * from tb_schoose ", conn);
                SqlDataReader sdr3 = cmd3.ExecuteReader();
                while (sdr3.Read())
                {
                    string sqlSChoose = "select tb_schoose.questionText,tb_schoose.chooseA,tb_schoose.chooseB,tb_schoose.chooseC,tb_schoose.chooseD,tb_schoose.questionID,tb_workexam.questionID,tb_workexam.SubjectType, tb_workexam.ExamID  from tb_schoose,tb_workexam where tb_schoose.questionID=tb_workexam.questionID  and tb_workexam.SubjectType='单选' and  tb_workexam.ExamID='" + Label10.Text + "'";
                    BaseClass.BindDG(GridView1, "questionID", sqlSChoose, "SingleChooseInfo");
                }
                conn.Close();

                conn.Open();
                SqlCommand cmd4 = new SqlCommand("select * from tb_mchoose ", conn);
                SqlDataReader sdr4 = cmd4.ExecuteReader();
                while (sdr4.Read())
                {
                    string sqlMChoose = "select tb_mchoose.questionText,tb_mchoose.chooseA,tb_mchoose.chooseB,tb_mchoose.chooseC,tb_mchoose.chooseD,tb_mchoose.chooseE,tb_mchoose.chooseF,tb_mchoose.chooseG,tb_mchoose.chooseH,tb_mchoose.questionID,tb_workexam.questionID,tb_workexam.SubjectType, tb_workexam.ExamID  from tb_mchoose,tb_workexam where tb_mchoose.questionID=tb_workexam.questionID  and tb_workexam.SubjectType='多选' and  tb_workexam.ExamID='" + Label10.Text + "'";
                    BaseClass.BindDG(GridView5, "questionID", sqlMChoose, "MChooseInfo");
                }
                conn.Close();

                conn.Open();
                SqlCommand cmdjudge = new SqlCommand("select * from tb_judge", conn);
                SqlDataReader sdrjudge = cmdjudge.ExecuteReader();
                while (sdrjudge.Read())
                {
                    string sqlJudge = "select tb_judge.questionText,tb_workexam.questionID,tb_workexam.SubjectType, tb_workexam.ExamID  from tb_judge,tb_workexam where tb_judge.questionID=tb_workexam.questionID  and tb_workexam.SubjectType='判断' and  tb_workexam.ExamID='" + Label10.Text + "'";
                    BaseClass.BindDG(GridView2, "questionID", sqlJudge, "JudgeInfo");
                }
                conn.Close();

                conn.Open();
                SqlCommand cmdinput = new SqlCommand("select * from tb_input", conn);
                SqlDataReader sdrinput = cmdinput.ExecuteReader();
                while (sdrinput.Read())
                {
                    string sqlInput = "select tb_input.questionText,tb_workexam.questionID,tb_workexam.SubjectType, tb_workexam.ExamID  from tb_input,tb_workexam where tb_input.questionID=tb_workexam.questionID  and tb_workexam.SubjectType='填空' and  tb_workexam.ExamID='" + Label10.Text + "'";
                    BaseClass.BindDG(GridView3, "questionID", sqlInput, "InputInfo");

                }
                conn.Close();

                conn.Open();
                SqlCommand cmdquestion = new SqlCommand("select * from tb_application", conn);
                SqlDataReader sdrquestion = cmdquestion.ExecuteReader();
                while (sdrquestion.Read())
                {
                    string sqlApplication = "select tb_application.questionText,tb_workexam.questionID,tb_workexam.SubjectType, tb_workexam.ExamID  from tb_application,tb_workexam where tb_application.questionID=tb_workexam.questionID  and tb_workexam.SubjectType='应用' and  tb_workexam.ExamID='" + Label10.Text + "'";
                    BaseClass.BindDG(GridView4, "questionID", sqlApplication, "ApplicationInfo");
                }
                conn.Close();
            }
            else
            {
                Response.Write("<script>alert('现在不是考试时间');</script>");
            }
            conn.Open();
            string str="select * from tb_examResult where ExamID='"+Label10.Text.ToString()+"'and StudentID='"+Session["StudentID"].ToString()+"'"; 
              SqlCommand cmd121 = new SqlCommand(str, conn);
        SqlDataReader sdr121 = cmd121.ExecuteReader();
        sdr121.Read();
        if (sdr121.HasRows)
        {
            Response.Write("<script>alert('你已经交卷了，不能再考！');</script>");
            btnstart.Enabled = false;
        }
            conn.Close();
        }
    }

    protected void btnjj_Click(object sender, EventArgs e)
    {
        string sql = "select answer from tb_schoose ";
        conn.Open();
        SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, conn);
        DataSet dataset = new DataSet();
        dataAdapter.Fill(dataset, "tb_schoose");
        DataTable datatable = dataset.Tables["tb_schoose"];
        int c = 0;//存正确答案
        for (int a = 0; a < GridView1.Rows.Count; a++)
        {
            Label lblcs = (Label)(GridView1.Rows[a].FindControl("lblcs"));
            RadioButtonList rbanswers = (RadioButtonList)(GridView1.Rows[a].FindControl("rbanswers"));//取用户所选答案
            for (int i = 0; i < rbanswers.Items.Count; i++)
            {
                if (rbanswers.Items[i].Selected == true)
                {
                    string answer = rbanswers.Items[i].Value;
                    string answer1 = datatable.Rows[a]["answer"].ToString().Trim();//取正确答案
                    if (rbanswers.SelectedValue.ToString().Trim() == answer)//比较
                    {
                        c = c + 1;
                    }
                }
            }
        }
        //btnjj.Enabled = false;//交完一次就不能在交
        string sql1 = "select answer from tb_mchoose ";
        SqlDataAdapter dataAdapter1 = new SqlDataAdapter(sql1, conn);
        DataSet dataset1 = new DataSet();
        dataAdapter1.Fill(dataset1, "tb_mchoose");
        DataTable datatable1 = dataset1.Tables["tb_mchoose"];
        int b = 0;//存答正确答案
        for (int a = 0; a < GridView5.Rows.Count; a++)
        {
            CheckBoxList rbanswer11 = (CheckBoxList)(GridView5.Rows[a].FindControl("rbanswer11"));//取用户所选答案
            Label lblc11 = (Label)(GridView5.Rows[a].FindControl("lblc11"));
            string ans1 = "";
            for (int i = 0; i < rbanswer11.Items.Count; i++)
            {
                if (rbanswer11.Items[i].Selected == true)
                {
                    ans1 += rbanswer11.Items[i].Value;
                    string answer1 = datatable1.Rows[a]["answer"].ToString().Trim();//取正确答案
                    if (ans1 == answer1)//比较
                    {
                        b = b + 1;
                    }
                }
            }
        }
            int d = 0;//存答正确答案
            for (int a = 0; a < GridView3.Rows.Count; a++)
            {
                TextBox TextBox2 = (TextBox)(GridView3.Rows[a].FindControl("TextBox2"));//考生答案
                Label lbltk = (Label)(GridView3.Rows[a].FindControl("lbltk"));//填空题目
                if (TextBox2 != null)
                {
                    string qtid = GridView3.DataKeys[a].Value.ToString();
                    SqlCommand cmd = new SqlCommand("select answer from tb_input where questionID='" + qtid + "'", conn);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    string ans = sdr["answer"].ToString();     
                    sdr.Close();
                    if (TextBox2.Text == ans)//比较
                    {
                        d = d + 1;
                    }
                }
            }

            string sdrsql = "select answer from tb_judge ";
            SqlDataAdapter da = new SqlDataAdapter(sdrsql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "tb_judge");
            DataTable dt = ds.Tables["tb_judge"];
            int n = 0;//存答正确答案
            for (int a = 0; a < GridView2.Rows.Count; a++)
            {
                RadioButtonList rbanswer = (RadioButtonList)(GridView2.Rows[a].FindControl("rbanswer"));//取用户所选答案
                Label lblc = (Label)(GridView2.Rows[a].FindControl("lblc"));
                for (int i = 0; i < rbanswer.Items.Count; i++)
                {
                if (rbanswer.Items[i].Selected == true)
                {
                    string answer = dt.Rows[a]["answer"].ToString().Trim();//取正确答案
                    if (rbanswer.SelectedValue.ToString().Trim() == answer)//比较
                    {
                        n = n + 1;
                    }
                }
            }
        }
       
        //将学生应用题答案插入表中
        if (am != "0")
        {
            for (int a = 0; a < GridView4.Rows.Count; a++)
            {
                TextBox TextBox1 = (TextBox)(GridView4.Rows[a].FindControl("TextBox1"));
                Label lbljd = (Label)(GridView4.Rows[a].FindControl("lblc"));
                if (TextBox1 != null)
                {
                    string qtid = GridView4.DataKeys[a].Value.ToString();
                    SqlCommand cmd = new SqlCommand("select questionText from tb_application where questionID='" + qtid + "'", conn);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    string qt=sdr["questionText"].ToString();
                    sdr.Close();
                    string str11 = "insert into tb_studentexam(StudentID,ExamID,courseID,answer,questionText)  values('" + Session["StudentID"].ToString() + "','" + Label10.Text + "','" + Label11.Text + "','" + TextBox1.Text +  "','"+ qt + "')";
                    BaseClass.OperateData(str11);
                }
            }
            btnjj.Visible = false;
        }
        //计算学生客观题分数 并将分数插入成绩表
        int sr = Convert.ToInt32(Label12.Text.ToString().Trim()) * c;
        int ir = Convert.ToInt32(Label13.Text.ToString().Trim()) * d;
        int mr = Convert.ToInt32(Label14.Text.ToString().Trim()) * b;
        int jr = Convert.ToInt32(Label15.Text.ToString().Trim()) * n;
        int tt = sr + mr + ir+jr;
        string str1 = "insert into tb_examResult(StudentID,ExamID,SChooseResult,MChooseResult,InputResult,JudgeResult,TotalResult,courseID)  values('" + Session["StudentID"].ToString() + "','" + Label10.Text + "','" + sr + "','" + mr + "','" + ir + "','" + jr + "','" + tt + "','" + Label11.Text + "')";      
        SqlCommand cmd11 = new SqlCommand(str1, conn);
        SqlDataReader reader = cmd11.ExecuteReader();
        while (reader.Read())
        {
            Response.Write("<script>alert('交卷成功！');</script>");
        }  
        conn.Close();
    }
    protected void btnstart_Click(object sender, EventArgs e)
    {

        btnSchoose.Enabled = true;
        btnApplication.Enabled = true;
        btnMchoose.Enabled = true;
        btnJudge.Enabled = true;
        btnInput.Enabled = true;
        btnstart.Enabled = false;
        btnjj.Enabled = true;
    }
    protected void btnSchoose_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        Panel5.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = false;
    }
    protected void btnJudge_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel5.Visible = false;
        Panel2.Visible = true;
        Panel3.Visible = false;
        Panel4.Visible = false;
    }
    protected void btnInput_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel5.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = true;
        Panel4.Visible = false;
    }
    protected void btnApplication_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel5.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = true;
    }
    protected void btnMchoose_Click(object sender, EventArgs e)
    {
        Panel1.Visible = false;
        Panel5.Visible = true;
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = false;
    }
}




