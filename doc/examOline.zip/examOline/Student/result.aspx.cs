﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Student_result : System.Web.UI.Page
{
    SqlConnection conn = BaseClass.DBCon();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["StudentID"] == null)
        {
            Response.Redirect("Login.aspx");
         }

            if (!IsPostBack)
            {
                string str = "select * from tb_examResult where StudentID='" + Session["StudentID"].ToString() + "'";

                BaseClass.BindDG(GridView1, "StudentID", str, "stuinfo");
                string strsql = "select * from tb_student where StudentID='" + Session["StudentID"].ToString() + "'";
               
                conn.Open();
                SqlCommand cmd = new SqlCommand(strsql, conn);
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    label1.Text = sdr["StudentName"].ToString().Trim();
                }
                conn.Close();               
            }                       
}
    protected void link_Click(object sender, EventArgs e)
    {
      ;
    }
    protected void btncx_Click(object sender, EventArgs e)
    {
        if (tbx_query.Text == "")
        {
            string strsql = "select * from tb_examResult where StudentID='" + Session["StudentID"].ToString() + "'";
            BaseClass.BindDG(GridView1, "StudentID", strsql, "stuinfo");
        }
        else
        {
            string stype = DropDownList1.SelectedItem.Text;
            string strsql = "";
            switch (stype)
            {
                
                case "科目":
                    string strsql1 = "select courseID from tb_course where courseName ='" + tbx_query.Text.Trim() + "'";
                    conn.Open();
                      SqlCommand cmd = new SqlCommand(strsql1, conn);
                SqlDataReader sdr = cmd.ExecuteReader();
                sdr.Read();
                    string cid=sdr["courseID"].ToString();
                    conn.Close();
                    strsql = "select * from tb_examResult where courseID like '%" + cid + "%'";
                    BaseClass.BindDG(GridView1, "ExamID", strsql, "stuinfo");
                    break;
                case "总成绩":
                    strsql = "select * from tb_examResult where TotalResult like '%" + tbx_query.Text.Trim() + "%'";
                    BaseClass.BindDG(GridView1, "ExamID", strsql, "stuinfo");
                    break;

            }
        }
    }
}

